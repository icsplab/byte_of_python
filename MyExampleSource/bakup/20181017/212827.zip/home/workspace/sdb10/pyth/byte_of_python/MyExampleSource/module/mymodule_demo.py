import mymodule

mymodule.say_hi()
print 'version:', mymodule.__version__