from mymodule import say_hi, __version__

say_hi()
print 'version is', __version__